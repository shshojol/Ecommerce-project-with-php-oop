<h2>comodity reject Dasboard</h2>
<a href="?controller=comodityreject&view=create">Create new</a><br>
<?php  
   $cr = new comodityreject();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $cr->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($cr->select(), $controller);
?>
