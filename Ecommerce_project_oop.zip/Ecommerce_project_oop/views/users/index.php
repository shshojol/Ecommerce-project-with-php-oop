<h2>Users Dashboard</h2>
<a href="?controller=users&view=create">Create New</a><br>
<?php
$u = new users();
 


//table data deleted code
if(isset($_GET['id']))
{
   echo $u->makeDelete($_GET['id']);
}

//show table data

$html->table($u->select(), $controller);