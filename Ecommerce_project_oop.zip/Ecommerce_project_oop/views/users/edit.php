<?php
    $u = new users();
    $u->id = $_GET['id'];

    $ename = "";
    $econtact = "";
    $eemail = "";
   
    if(isset($_POST['submit']))
    {
        $u->filldata();
        $er = 0;
        if($u->name == "")
        {
            $er++;
            $ename = "<span class='error'>Required</span>";
        }

        if($u->contact == "")
        {
            $er++;
            $econtact = "<span class='error'>Required</span>";
        }

        if($u->email == "")
        {
            $er++;
            $eemail = "<span class='error'>Required</span>";
        }
        if($er == 0)
        {
           
            if($u->update())
            {
                echo "<span class='success'>user updated</span>";

            }
            else{
                echo "<span class='error'>".$u->error."</span>";
            }
        }
    }
    else{
        $u->selectbyid();
    }
?>

    
    <?php
        $html->FormStart();
        $html->text('name', $u->name, $ename);
        $html->text('contact', $u->contact, $econtact);
        $html->text('email', $u->email, $eemail);
        $html->password('password', $u->password);
        $html->date('dob', $u->dob);
        $html->textarea('address', $u->address);

        $gnd = new gender();
        $html->select('genderid', $gnd->select(), $u->genderid);

        $ct = new city();
        $html->select('cityid', $ct->select(), $u->cityid);

        $html->text('image', $u->image);
        $html->text('type', $u->type);
        $html->text('createdate', $u->createdate);
        $html->text('createip', $u->createip);
        $html->submit('submit', 'update');
        $html->FormEnd();
    ?>

    
