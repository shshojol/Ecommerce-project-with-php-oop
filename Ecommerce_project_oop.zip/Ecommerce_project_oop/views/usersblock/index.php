<h2>User Block Dashboard</h2>
<a href="?controller=usersblock&view=create">Create New</a><br>
<?php
$ub = new usersblock();
 


//table data deleted code
if(isset($_GET['id']))
{
   $ub->userid = $_GET['id'];
   if($ub->delete())
   {
      echo "data deleted";
   }
   else{
      echo $ub->error;
   }
}

//show table data
$html->table($ub->select(), $controller);