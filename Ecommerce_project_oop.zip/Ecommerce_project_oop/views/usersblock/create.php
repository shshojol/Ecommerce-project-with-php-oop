<?php
$ub = new usersblock();
$euserid = "";
$edatefrom = "";
$edateto = "";
$eremarks = "";
$eadminuserid = "";



if(isset($_POST['submit']))
{
    $ub->filldata();

    $er = 0;
    if($ub->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($ub->datefrom == "")
    {
        $er++;
        $edatefrom = "<span>Required</span>";
    }
    if($ub->datefrom == "")
    {
        $er++;
        $edatefrom = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($ub->insert())
        {
            echo "data saved";
            $ub = new usersblock();
        }
        else{
            mysqli_error($cn);
        }
    }
}

$html->FormStart();


$u = new users();
$html->select("userid", $u->select(), $ub->userid, $euserid);
$html->date("datefrom", $ub->datefrom, $edatefrom);
$html->date("dateto", $ub->dateto, $edateto);
$html->text("remarks", $ub->remarks, $eremarks);
$html->select("adminuserid", $u->select(), $ub->adminuserid, $eadminuserid);

$html->submit();
$html->FormEnd();