<?php
$cr = new comoditysold();
$cr->comodityid = $_GET['id'];


$ecomodityid = "";
$euserid = "";

if(isset($_POST['submit']))
{
    $cr->filldata();

    $er = 0;
    if($cr->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($cr->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($cr->update())
        {
            echo "Comodity Rejected updated";
        }
        else{
            echo $cr->error;
        }
    }
}else{
    $cr->selectbyid();
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $cr->comodityid, $ecomodityid);

$u = new users();
$html->select("userid", $u->select(), $cr->userid, $euserid);

$html->text("remarks", $cr->remarks);
$html->submit();
$html->FormEnd();