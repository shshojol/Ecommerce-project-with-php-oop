<h2>comodity sold Dasboard</h2>
<a href="?controller=comoditysold&view=create">Create new</a><br>
<?php  
   $cr = new comoditysold();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $cr->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($cr->select(), $controller);
?>
