<h2>Comodity condition Dasboard</h2>
<a href="?controller=comoditycondition&view=create">Create new</a><br>
<?php  
   $c = new comoditycondition();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $c->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($c->select(), $controller);
?>
