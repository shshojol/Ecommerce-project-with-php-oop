<?php
$cc = new comoditycondition();
$cc->id = $_GET['id'];


$ename = "";
$edescription = "";
$erating = "";

if(isset($_POST['submit']))
{
    $cc->filldata();

    $er = 0;
    if($cc->name == "")
    {
        $er++;
        $ename = "<span>Required</span>";
    }
    if($cc->description == "")
    {
        $er++;
        $edescription = "<span>Required</span>";
    }
    if($cc->rating == "")
    {
        $er++;
        $erating = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($cc->update())
        {
            echo "data updated";
        }
        else{
            mysqli_error($cn);
        }
    }
}
else{
    $cc->selectbyid();
}

$html->FormStart();
$html->text("name", $cc->name, $ename);
$html->textarea("description", $cc->description, $edescription);
$html->text("rating", $cc->rating, $erating);
$html->submit();
$html->FormEnd();