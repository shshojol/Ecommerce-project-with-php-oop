<h2>User Rating Dashboard</h2>
<a href="?controller=usersrating&view=create">Create New</a><br>
<?php
$ur = new usersrating();
 


//table data deleted code
if(isset($_GET['id']))
{
   echo $ur->makeDelete($_GET['id']);
}

//show table data

$html->table($ur->select(), $controller);