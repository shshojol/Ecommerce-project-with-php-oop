<?php
$ur = new usersrating();


$euserid = "";
$eratebyuserid = "";
$erating = "";

if(isset($_POST['submit']))
{
    $ur->filldata();

    $er = 0;
    if($ur->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($ur->ratebyuserid == "0")
    {
        $er++;
        $eratebyuserid = "<span>Required</span>";
    }
    if($ur->rating == "")
    {
        $er++;
        $erating = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($ur->insert())
        {
            echo "data saved";
            $ur = new usersrating();
        }
        else{
            echo $ur->error;
        }
    }
}

$html->FormStart();


$u = new users();
$html->select("userid", $u->select(), $ur->userid, $euserid);
$html->select("ratebyuserid", $u->select(), $ur->ratebyuserid, $eratebyuserid);
$html->text("rating", $ur->rating, $erating);
$html->submit();
$html->FormEnd();