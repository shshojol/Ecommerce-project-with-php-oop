<?php
$ur = new usersrating();
$ur->userid = $_GET['id'];

$euserid = "";
$eratebyuserid = "";
$erating = "";

if(isset($_POST['submit']))
{
    $ur->filldata();

    $er = 0;
    if($ur->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($ur->ratebyuserid == "0")
    {
        $er++;
        $eratebyuserid = "<span>Required</span>";
    }
    if($ur->rating == "")
    {
        $er++;
        $erating = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($ur->update())
        {
            echo "data updated";
        }
        else{
            echo $ur->error;
        }
    }
}
else{
    $ur->selectbyid();
}

$html->FormStart();


$u = new users();
$html->select("userid", $u->select(), $ur->userid, $euserid);
$html->select("ratebyuserid", $u->select(), $ur->ratebyuserid, $eratebyuserid);
$html->text("rating", $ur->rating, $erating);
$html->submit();
$html->FormEnd();