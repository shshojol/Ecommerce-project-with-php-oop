<h2>comodity approved Dasboard</h2>
<a href="?controller=comodityapproved&view=create">Create new</a><br>
<?php  
   $ca = new comodityapproved();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $ca->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($ca->select(), $controller);
?>
