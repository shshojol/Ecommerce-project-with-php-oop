<h2>comodity link Dasboard</h2>
<a href="?controller=comodityvideo&view=create">Create new</a><br>
<?php  
   $cv = new comodityvideo();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $cv->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($cv->select(), $controller);
?>
