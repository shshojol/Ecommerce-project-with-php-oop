<?php
$cv = new comodityvideo();


$ecomodityid = "";
$elink = "";

if(isset($_POST['submit']))
{
    $cv->filldata();

    $er = 0;
    if($cv->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($cv->videolink == "")
    {
        $er++;
        $elink = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($cv->insert())
        {
            echo "video link inserted";
            $cv = new comodityvideo();
        }
        else{
            echo $cv->error;
        }
    }
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $cv->comodityid, $ecomodityid);

$html->text("videolink", $cv->videolink, $elink);
$html->text("title", $cv->title);
$html->submit();
$html->FormEnd();