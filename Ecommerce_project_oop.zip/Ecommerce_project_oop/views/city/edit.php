<?php
$ct = new city();

$ct->id = $_GET['id'];

$ct->name = ""; 
$ct->countryid = "";
$ecity = "";
$ecountry = "";

if(isset($_POST['submit']))
{
    $ct->name = $_POST['name'];
    $ct->countryid = $_POST['countryid'];
    $er = 0;
    if($ct->name == "")
    {
        $er++;
        $ecity = "required";
    }
    if($ct->countryid == "0")
    {
        $er++;
        $ecountry = "required";
    }
    if($er == 0)
    {
        if($ct->update())
        {
            echo "city updated";
        }
        else{
            echo $ct->error;
        }
    }
}
else{
  $ct->id = $_GET['id'];
  $ct->selectbyid();
}

$html->FormStart();
$html->text('name', $ct->name, $ecity);
$cnt = new country();
$html->select('countryid', $cnt->select(), $ct->countryid, $ecountry);
$html->submit("submit", 'update');
$html->FormEnd();