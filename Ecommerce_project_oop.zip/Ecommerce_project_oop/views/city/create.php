<?php
$ct = new city();
$ct->name = "";
$ct->countryid = "";

$ename = "";
$ecountryid = "";

if(isset($_POST['submit']))
{
    $ct->filldata();

    $er = 0;
    if($ct->name == "")
    {
        $er++;
        $ename = "<span>Required</span>";
    }
    if($ct->countryid == "0")
    {
        $er++;
        $ecountryid = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($ct->insert())
        {
            echo "data saved";
            $ct = new city();
        }
        else{
            mysqli_error($cn);
        }
    }
}

$html->FormStart();
$html->text("name", $ct->name, $ename);

$cnt = new country();
$html->select("countryid", $cnt->select(), $ct->countryid, $ecountryid);

$html->submit();
$html->FormEnd();