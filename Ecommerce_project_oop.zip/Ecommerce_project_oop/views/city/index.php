<h2>City Dashboard</h2>
<a href="?controller=city&view=create">Create New</a><br>
<?php
$ct = new city();
 //srch button
 $search = "";
 $country = "";
 if(isset($_POST['btnSearch']))
 {
      $search = $_POST['search'];
      $country = $_POST['country'];
 }
 $html->FormStart();
 $html->text('search', $search);

 $cnt = new country();
 $html->select('country', $cnt->select(), $country);
 $html->submit('btnSearch', 'Search');
 $html->FormEnd();


//table data deleted code
if(isset($_GET['id']))
{
   echo $ct->makeDelete($_GET['id']);
}

//show table data
$ct->search = $search;
$ct->countryid = $country;
$html->table($ct->select(), $controller);