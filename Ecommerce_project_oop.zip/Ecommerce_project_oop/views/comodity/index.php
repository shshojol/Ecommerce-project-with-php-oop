<h2>comodity Dashboard</h2>
<a href="?controller=comodity&view=create">Create New</a><br>
<?php
$c = new comodity();
 


//table data deleted code
if(isset($_GET['id']))
{
   echo $c->makeDelete($_GET['id']);
}

//show table data

$html->table($c->select(), $controller);