<?php
    $c = new comodity();
    $c->id = $_GET['id'];

    $etitle = "";
    $edescription = "";
    $econditionid = "";
    $elocationid = "";
    $euserid = "";
    $epriorityid = "";
   
    if(isset($_POST['submit']))
    {
        $c->filldata();
        $er = 0;
        if($c->title == "")
        {
            $er++;
            $etitle = "<span class='error'>Required</span>";
        }

        if($c->description == "")
        {
            $er++;
            $edescription = "<span class='error'>Required</span>";
        }

        if($c->conditionid == "0")
        {
            $er++;
            $econditionid = "<span class='error'>Required</span>";
        }
        if($c->locationid == "0")
        {
            $er++;
            $elocationid = "<span class='error'>Required</span>";
        }
        if($c->priorityid == "0")
        {
            $er++;
            $epriorityid = "<span class='error'>Required</span>";
        }
        if($c->userid == "0")
        {
            $er++;
            $euserid = "<span class='error'>Required</span>";
        }
        if($er == 0)
        {
           
            if($c->update())
            {
                echo "<span class='success'>comodity updated</span>";

            }
            else{
                echo "<span class='error'>".$c->error."</span>";
            }
        }
    }else{
        $c->selectbyid();
    }





        $html->FormStart();
        $html->text('title', $c->title, $etitle);
        $html->textarea('description', $c->description, $edescription);

        $cc = new comoditycondition();
        $html->select('conditionid', $cc->select(), $c->conditionid, $econditionid);

        $loc = new location();
        $html->select('locationid', $loc->select(), $c->locationid, $elocationid);

        $p = new priority();
        $html->select('priorityid', $p->select(), $c->priorityid, $epriorityid);

        $u = new users();
        $html->select('userid', $u->select(), $c->userid, $euserid);

        $html->text('ip', $c->ip);

        $html->submit('submit', 'create');
        $html->FormEnd();
?>

    
