<h2>comodity image Dasboard</h2>
<a href="?controller=comodityimage&view=create">Create new</a><br>
<?php  
   $img = new image();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $img->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($img->select(), $controller, "image", "<img height='80px' src=\"uploads/image/#replace#\"/>");
?>
