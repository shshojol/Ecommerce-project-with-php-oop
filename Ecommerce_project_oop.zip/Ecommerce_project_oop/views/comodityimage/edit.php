<?php
$img = new image();
$img->id = $_GET['id'];


$image = array();
$ecomodityid = "";
$eimage = "";

if(isset($_POST['submit']))
{
    $img->filldata();
    $image = $_FILES['image'];
    $img->image = $image['name'];

 

    $er = 0;
    if($img->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($image['name'] == "")
    {
        $er++;
        $eimage = "<span>Required</span>";
    }
    if($er == 0)
    {
        
        if($img->update())
        {
            $cn = mysqli_connect("localhost", "root", "", "bitm2");
            $sp = $image['tmp_name'];
            $dp = "uploads/image/".$image['name'];
            move_uploaded_file($sp, $dp);
            echo "image updated";
            $img = new image();
            $image = array();
        }
        else{
            echo $img->error;
        }
    }
}else{
    $img->selectbyid();
}

$html->FormStart('post', '', "enctype='multipart/form-data'");


$c = new comodity();
$html->select("comodityid", $c->select(), $img->comodityid, $ecomodityid);

$html->file("image", $eimage);
$html->text("title", $img->title);
$html->submit();
$html->FormEnd();