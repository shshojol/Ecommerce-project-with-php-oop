<?php
            $msg = new messages();
            $emessage = "";
            if(isset($_POST['submit']))
            {
                $msg->comodityid = $_GET['comodity'];
                $msg->userid = $_SESSION['id'];
                $msg->datetime = date("Y-m-d");
                $msg->message = $_POST['message'];

                $er = 0;
                if($msg->message == "")
                {
                    $er++;
                    $emessage = "required";
                }
                if($er == 0)
                {
                    if($msg->insert())
                    {
                        $msg = new messages();
                    }else{
                        echo $html->errorBlock($msg->error);
                    }
                }               
            }
?>
<div class="row">
    <div class= "col-md-2" style = "background-color:silver">
        <ul>
            <?php
                $cm = new comodity();
                $cm->userid = $_SESSION['id'];
                $c = $cm->select();
                foreach($c as $com)
                {
                    echo "<li><a href='?controller=public&view=message&comodity=".$com['id']."'>".$com['name']."</a></li>";
                }
            ?>
        </ul>
    </div>
    <div class= "col-md-10" style = "background-color:grey;">
    <?php
        if(isset($_GET['comodity']))
        {
            $msg = new messages();
            $msg->userid = $_SESSION['id'];
            $msg->comodityid = $_GET['comodity'];
            $m = $msg->select();
            foreach($m as $ms)
            {
                echo "<p  style = 'background-color:white; margin:5px'><b>".$ms['user']." </b> on ".$ms['datetime']." : ".$ms['message']."</p>";
            }
        } 
        else{
            $msg = new messages();
            $msg->userid = $_SESSION['id'];
            $m = $msg->select();
            foreach($m as $ms)
            {
                echo "<p  style = 'background-color:white; margin:5px'><b>".$ms['user']." </b> on ".$ms['datetime']." : ".$ms['message']."</p>";
            } 
        }  
    ?>
    </div>
    <div class="col-md-12">
      <?php
           if(isset($_GET['comodity']))
           {
               echo $html->formStart();
               echo $html->textarea('message',$msg->message, $emessage);
               echo $html->submit('submit', 'Send');
               echo $html->formEnd();      
           }
        ?>
    </div>
</div>