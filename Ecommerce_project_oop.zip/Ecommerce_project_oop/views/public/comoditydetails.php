<link rel='stylesheet' href='css/comoditydetails.css'/>
<script type="text/javascript">
    function changeimage(id)
    {
        document.getElementById('mainimage').setAttribute("src",
        
        document.getElementById(id).getAttribute("src"));
    }
</script>
<?php
$html = new htmlhelper();
$mg = new messages();
$emassage = "";
if(isset($_POST['submit']))
{
    $mg->message = $_POST['message'];
    $mg->comodityid = $_GET['id'];
    $mg->userid = $_SESSION['id'];
     $er=0;
    if($mg->message == "")
    {
        $er++;
        $emassage = "required";
    }
    if($er == 0)
    {
        if($mg->insert())
        {
            $mg = new messages();
        }else{
            
        }
    }
}


$cm = new comodity();
$cm->id = $_GET['id'];
$a = $cm->select();

foreach($a as $item)
{
    echo "<div class='comoditydetails'>";
        $ci = new image();
        $ci->comodityid = $item['id'];
        $im = $ci->select();
        $i = 0;

        echo '<div class="container row">';
        echo '<div class="col-md-6">';
        foreach($im as $img)
        {
            if($i == 0)
            {
                echo "<img id='mainimage' class=\"mainimage\" src='uploads/image/".$img['image']."' alt=\"Card image\"  >"; 
            }
                echo '<img id="subimage'.$i.'" onclick="changeimage(\'subimage'.$i.'\')"; class = "subimage" src="uploads/image/'.$img["image"].'">';
            $i++;
        }
        echo "</div>";
        


        echo '<div class="col-md-6">';
            echo "<div class=\"comoditybody\">";
            echo " <h2 class=\"card-title\">".$item['name']."</h2>";
            echo "<h6>Posted on: ".$item['datetime']." By: ".$item['user']." Condition: ".$item['condition']."</h6>";
           
            $cp = new comodityprice();
            $cp->comodityid = $item['id'];
            $a = $cp->select();
            foreach($a as $price)
            {
                echo "<span>Regular price: ".$price['regularprice']." now ".$price['price']."</span>";
            }
          
            echo " <p class=\"card-text\">".$item['description']."</p>";
            echo "<div>";
                $msg = new messages();
                $msg->comodityid = $item['id'];
                $m = $msg->select();
                echo "message: ".count($m)." | <a href='?controller=public&view=message&comodity=".$item['id']."'>Send message</a>";
            echo "</div>";

            $usr = new usersrating();
            $usr->userid = $item['userid'];
            $usrs = $usr->select();
            $sum = 0;
            foreach($usrs as $v)
            {
                $sum = $sum + $v['rating'];
            }
            $avg = $sum/count($usrs);
            echo "<div>";
            
                echo "User Rating: ".$avg ." / 10 of  ". count($usrs)."";
            echo "</div>";
            echo "</div>";
        
    echo "</div>";
    echo "</div>";
echo "</div>";
}
echo "<div class='comoditydetails-comment'>";
$msg = new messages();
$msg->comodityid = $_GET['id'];
$table = $msg->select();
foreach($table as $ms)
{
    echo "<b>".$ms['user']."</b> ";
    echo "<span class='comment'>".$ms['message']."</span><br>";
}
echo "</div>";


$html->formStart();
$html->textarea("message", $mg->message, $emassage);
$html->submit();
$html->formEnd();

