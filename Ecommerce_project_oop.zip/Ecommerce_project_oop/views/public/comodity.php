<link rel='stylesheet' href='css/comodity.css'/>
<?php
$cm = new comodity();
$a = $cm->select();

foreach($a as $item)
{
    
    echo "<div class='comodity'>";
        echo "<div class=\"card\" style=\"width:400px\">";

        $ci = new image();
        $ci->comodityid = $item['id'];
        $i = $ci->select();
        echo "<a href='?controller=public&view=comoditydetails&id=".$item['id']."'>";
        foreach($i as $img)
        {
            echo " <img class=\"card-img-top\" src='uploads/image/".$img['image']."' alt=\"Card image\" style='height:200px' >";
            break;
        }
        echo "</a>";


            
            echo "<div class=\"card-body\">";
            echo " <h2 class=\"card-title\">".$item['name']."</h2>";
            echo "<h6>Posted on: ".$item['datetime']." By: ".$item['user']." Condition: ".$item['condition']."</h6>";
           
            $cp = new comodityprice();
            $cp->comodityid = $item['id'];
            $a = $cp->select();
            foreach($a as $price)
            {
                echo "<span>Regular price: ".$price['regularprice']." now ".$price['price']."</span>";
            }
          
            echo " <p class=\"card-text\">".$item['description']."</p>";
            echo "<div>";
                $msg = new messages();
                $msg->comodityid = $item['id'];
                $m = $msg->select();
                echo "message: ".count($m)." | <a href='?controller=public&view=message&comodity=".$item['id']."'>Send message</a>";
            echo "</div>";

            $usr = new usersrating();
            $usr->userid = $item['userid'];
            $usrs = $usr->select();
            $sum = 0;
            foreach($usrs as $v)
            {
                $sum = $sum + $v['rating'];
            }
            $avg = $sum/count($usrs);
            echo "<div>";
            
                echo "User Rating: ".$avg ." / 10 of  ". count($usrs)."";
            echo "</div>";
            echo "</div>";
        echo "</div>";
    echo "</div>";
}
