<h2>Enter Your Needs</h2>
<?php
    $c = new comodity();
    $lnk = new link();
    $ci = new image();
    $cp = new comodityprice();

    $etitle = "";
    $edescription = "";
    $econditionid = "";
    $elocationid = "";
    $euserid = "";
    $epriorityid = "";
   
    if(isset($_POST['submit']))
    {
        $c->filldata();
        $c->ip = $_SERVER['REMOTE_ADDR'];
        $c->userid = $_SESSION['id'];
        $cp->filldata();
        $er = 0;
        if($c->title == "")
        {
            $er++;
            $etitle = "<span class='error'>Required</span>";
        }

        if($c->description == "")
        {
            $er++;
            $edescription = "<span class='error'>Required</span>";
        }

        if($c->conditionid == "0")
        {
            $er++;
            $econditionid = "<span class='error'>Required</span>";
        }
        if($c->locationid == "0")
        {
            $er++;
            $elocationid = "<span class='error'>Required</span>";
        }
        if($c->priorityid == "0")
        {
            $er++;
            $epriorityid = "<span class='error'>Required</span>";
        }
        if($c->userid == "0")
        {
            $er++;
            $euserid = "<span class='error'>Required</span>";
        }
        if($er == 0)
        {
           
            if($c->insert())
            {

                $cp->comodityid = $c->lastid;
                if(!$cp->insert())
                {
                    echo $html->error($cp->error);
                }
                $cp = new comodityprice();

                $lnk->comodityid = $c->lastid;
                for($i = 0; $i < count($_POST['link']); $i++)
                {
                    $lnk->link = $_POST['link'][$i];
                    $lnk->title = $_POST['ltitle'][$i];
                    if(!$lnk->insert())
                    {
                        $html->error($lnk->error);
                    }
                }

                $ci->comodityid = $c->lastid;
                for($i = 0; $i < count($_POST['ititle']); $i++)
                {
                    echo "<pre>";
                    var_dump($_FILES);
                    $ci->image = $_FILES['image']['name'][$i];
                    $ci->title = $_POST['ititle'][$i];
                    if($ci->insert())
                    {
                        $sp = $_FILES['image']['tmp_name'][$i];
                        $dp = "uploads/image".$ci->image;
                        move_uploaded_file($sp, $dp);
                    }
                    else{
                        $html->error($ci->error);
                    }
                }


                echo $html->success('comodity added');
                $c = new comodity();
            }
            else{
                echo "<span class='error'>".$c->error."</span>";
            }
        }
    }
?>

    
    <?php
        $html->FormStart();
        $html->text('title', $c->title, $etitle);
        $html->textarea('description', $c->description, $edescription);

        $cc = new comoditycondition();
        $html->select('conditionid', $cc->select(), $c->conditionid, $econditionid);

        $loc = new location();
        $html->select('locationid', $loc->select(), $c->locationid, $elocationid);

        $p = new priority();
        $html->select('priorityid', $p->select(), $c->priorityid, $epriorityid);
?>
    <div class='container row'>
        <div class='col-md-3'>
            <?php
                $html->text('regularprice', $cp->regularprice);
                $html->text('price', $cp->price);
            ?>
        </div>
        <div id="clinks" class='col-md-3'>
            <div><a href="#" onclick="addlinks()">add more link</a></div>
            <div id= "firstitem">
                <?php
                    $html->text('link[]', $lnk->link);
                    $html->text('ltitle[]', $lnk->title);
                ?>
            </div>
        </div>
        <div id="cimages" class='col-md-3'>
            <div><a href="#" onclick="addimages()">add more image</a></div>
            <div id= "firstitemimage">
                <?php
                    $html->file('image[]');
                    $html->text('ititle[]', $ci->title);
                ?>
            </div>
        </div>
    </div>
<?php

        $html->submit('submit', 'create');
        $html->FormEnd();
    ?>

   <script type='text/javascript'>
        function addlinks()
        {
            document.getElementById('clinks').innerHTML = document.getElementById('clinks').innerHTML + document.getElementById('firstitem').innerHTML;
            alert('link added');
        }
        function addimages()
        {
            document.getElementById('cimages').innerHTML = document.getElementById('cimages').innerHTML + document.getElementById('firstitemimage').innerHTML;
            alert('link added');
        }
   </script> 
