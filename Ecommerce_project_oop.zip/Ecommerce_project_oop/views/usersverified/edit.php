<?php
$uv = new usersverified();
$uv->userid = $_GET['id'];

$euserid = "";
$emethod = "";
$eadminuserid = "";

if(isset($_POST['submit']))
{
    $uv->filldata();

    $er = 0;
    if($uv->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($uv->adminuserid == "0")
    {
        $er++;
        $eadminuserid = "<span>Required</span>";
    }
    if($uv->method == "")
    {
        $er++;
        $emethod = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($uv->update())
        {
            echo "data updated";
            $uv = new usersverified();
        }
        else{
            echo $ur->error;
        }
    }
}
else{
    $uv->selectbyid();
}

$html->FormStart();


$u = new users();
$html->select("userid", $u->select(), $uv->userid, $euserid);
$html->select("adminuserid", $u->select(), $uv->adminuserid, $eadminuserid);
$html->text("method", $uv->method, $emethod);
$html->submit();
$html->FormEnd();