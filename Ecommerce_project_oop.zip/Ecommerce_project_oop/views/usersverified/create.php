<?php
$uv = new usersverified();


$euserid = "";
$emethod = "";
$eadminuserid = "";

if(isset($_POST['submit']))
{
    $uv->filldata();

    $er = 0;
    if($uv->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($uv->adminuserid == "0")
    {
        $er++;
        $eadminuserid = "<span>Required</span>";
    }
    if($uv->method == "")
    {
        $er++;
        $emethod = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($uv->insert())
        {
            echo "data saved";
            $uv = new usersverified();
        }
        else{
            echo $ur->error;
        }
    }
}

$html->FormStart();


$u = new users();
$html->select("userid", $u->select(), $uv->userid, $euserid);
$html->select("adminuserid", $u->select(), $uv->adminuserid, $eadminuserid);
$html->text("method", $uv->method, $emethod);
$html->submit();
$html->FormEnd();