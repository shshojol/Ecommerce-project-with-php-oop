<h2>User verified Dashboard</h2>
<a href="?controller=usersverified&view=create">Create New</a><br>
<?php
$uv = new usersverified();
 


//table data deleted code
if(isset($_GET['id']))
{
   echo $uv->makeDelete($_GET['id']);
}

//show table data

$html->table($uv->select(), $controller);