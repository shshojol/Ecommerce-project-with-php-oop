<?php

$html->errorBlock(isset($_SESSION['message'])?$_SESSION['message']: "");

$usr = new users();
$eemail = "";
$epassword = "";

if(isset($_POST['btnLoginPublic']))
{
    $usr = new users();
    $usr->email = $_POST['email'];
    $usr->password = $_POST['password'];

    $er = 0;

    if($usr->email == "")
    {
        $er++;
        $eemail = "required";
    }
    if($usr->password == "")
    {
        $er++;
        $epassword = "required";
    }
}


$html->FormStart();
$html->text('email', $usr->email, $eemail);
$html->password('password', $epassword);
$html->submit('btnLoginPublic', 'Login');
$html->FormEnd();