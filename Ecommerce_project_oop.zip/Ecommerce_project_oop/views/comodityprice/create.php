<?php
$cp = new comodityprice();


$ecomodityid = "";
$eregularprice = "";

if(isset($_POST['submit']))
{
    $cp->filldata();

    $er = 0;
    if($cp->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($cp->regularprice == "")
    {
        $er++;
        $eregularprice = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($cp->insert())
        {
            echo "price uploaded";
            $cp = new comodityprice();
        }
        else{
            echo $cp->error;
        }
    }
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $cp->comodityid, $ecomodityid);

$html->text("regularprice", $cp->regularprice, $eregularprice);
$html->text("price", $cp->price);
$html->submit();
$html->FormEnd();