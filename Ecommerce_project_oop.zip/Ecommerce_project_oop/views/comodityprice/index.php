<h2>comodity link Dasboard</h2>
<a href="?controller=comodityprice&view=create">Create new</a><br>
<?php  
   $cp = new comodityprice();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $cp->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($cp->select(), $controller);
?>
