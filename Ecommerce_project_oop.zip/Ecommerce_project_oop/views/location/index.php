<h2>Location Dasboard</h2>
<a href="?controller=location&view=create">Create new</a><br>
<?php  
   $loc = new location();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $loc->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($loc->select(), $controller);
?>
