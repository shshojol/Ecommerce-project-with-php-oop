<?php
$gnd = new location();


$ename = "";
$ecityid = "";

if(isset($_POST['submit']))
{
    $gnd->filldata();

    $er = 0;
    if($gnd->name == "")
    {
        $er++;
        $ename = "<span>Required</span>";
    }
    if($gnd->cityid == "0")
    {
        $er++;
        $ecityid = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($gnd->insert())
        {
            echo "data saved";
            $gnd = new location();
        }
        else{
            mysqli_error($cn);
        }
    }
}

$html->FormStart();
$html->text("name", $gnd->name, $ename);

$c = new city();
$html->select("cityid", $c->select(), $gnd->cityid, $ecityid);
$html->submit();
$html->FormEnd();