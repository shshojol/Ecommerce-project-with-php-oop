<?php
$ua = new loginhistory();
$ua->userid = $_GET['id'];

$euserid = "";



if(isset($_POST['submit']))
{
    $ua->filldata();

    $er = 0;
    if($ua->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($ua->update())
        {
            echo "history updated";
            $ua = new uactive();
        }
        else{
            echo $ua->erro;
        }
    }
}
else{
    $ua-> selectbyid();
}

$html->FormStart();

$u = new users();
$html->select("userid", $u->select(), $ua->userid, $euserid);
$html->text("ip", $ua->ip);

$html->submit('submit', 'Update');
$html->FormEnd();