<h2>Login History Dasboard</h2>
<a href="?controller=loginhistory&view=create">Create</a><br>
<?php  
   $ua = new loginhistory();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $ua->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($ua->select(), $controller);
?>
