<?php
$gnd = new gender();


$ename = "";
$edescription = "";

if(isset($_POST['submit']))
{
    $gnd->filldata();

    $er = 0;
    if($gnd->name == "")
    {
        $er++;
        $ename = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($gnd->insert())
        {
            echo "data saved";
            $gnd = new gender();
        }
        else{
            mysqli_error($cn);
        }
    }
}

$html->FormStart();
$html->text("name", $gnd->name, $ename);
$html->textarea("description", $gnd->description);
$html->submit();
$html->FormEnd();