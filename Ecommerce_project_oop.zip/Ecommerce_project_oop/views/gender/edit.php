<?php
$gnd = new gender();
$gnd->id = $_GET['id'];

$ename="";
$edescription="";

if(isset($_POST['submit']))
{
    $gnd->name = $_POST['name'];
    $er = 0;
    if($gnd->name == "")
    {
        $er++;
        $ename = "required";
    }
    if($er == 0)
    { 
        if($gnd->update())
        {
            echo 'data updated';
        }
        else{
            echo $gnd->error;
        } 
    }
}
else{
    $gnd->id = $_GET['id'];
    $gnd->selectById();
}
//form table
$html->FormStart();
$html->text('name', $gnd->name, $ename);
$html->textarea('description', $gnd->description);
$html->submit('submit', 'Update');
$html->FormEnd();
