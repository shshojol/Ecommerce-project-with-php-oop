<h2>Gender Dasboard</h2>
<a href="?controller=gender&view=create">Create gender</a><br>
<?php  
   $gnd = new gender();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $gnd->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($gnd->select(), $controller);
?>
