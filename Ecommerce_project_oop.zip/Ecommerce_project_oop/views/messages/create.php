<?php
$m = new messages();


$ecomodityid = "";
$euserid = "";
$emessage = "";

if(isset($_POST['submit']))
{
    $m->filldata();

    $er = 0;
    if($m->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($m->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($m->message == "")
    {
        $er++;
        $emessage = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($m->insert())
        {
            echo "data saved";
            $m = new messages();
        }
        else{
            echo $ca->error;
        }
    }
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $m->comodityid, $ecomodityid);


$u = new users();
$html->select("userid", $u->select(), $m->userid, $euserid);

$html->text("message", $m->message, $emessage);
$html->submit();
$html->FormEnd();