<h2>comodity message Dasboard</h2>
<a href="?controller=messages&view=create">Create new</a><br>
<?php  
   $m = new messages();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $m->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($m->select(), $controller);
?>
