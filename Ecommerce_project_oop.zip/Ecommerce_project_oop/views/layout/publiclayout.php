
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel='stylesheet' href='css/publiclayout.css'/>
    <link rel='stylesheet' href='css/publicmenu/menu.css'/>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>Ponnor Hat <?Php title();?></title>
</head>
<body>
    <div>
        <h1>ponner hat</h1>
        <h2>admin panel</h2>
    </div>
    
    <div style="overflow:hidden;">
        <div>
             <?php
                include('views/layout/publicmenu.php');
            ?>
        </div>
        <div  class='container'>
            <?php 
                renderbody(); 
            ?>
        </div>
    </div>
    <div>@copyright ponnerhat.com <?php echo date('Y');?></div>
</body>
</html>