<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
<ul class="navbar-nav">
    <li class="nav-item"><a class="nav-link" href='?controller=public&view=index'>Home</a></li>
    <li class="nav-item"><a class="nav-link" href='?controller=public&view=i_need_something'>I Need Something</a></li>
    <li class="nav-item"><a class="nav-link" href='?controller=public&view=comodity'>Comodity</a></li>
    <li class="nav-item"><a class="nav-link" href='?controller=public&view=message'>Message</a></li>
    <?php
        if(isset($_SESSION['type']))
        {
            print "<li class=\"nav-item\"><a class=\"nav-link\" href='?controller=account&view=myaccount'>".$_SESSION['name']."</a></li>";
            print "<li class=\"nav-item\"><a class=\"nav-link\" href='?controller=account&view=logout'>Logout</a></li>";
            if($_SESSION['type'] == 'A')
            {
                print "<li class=\"nav-item\"><a class=\"nav-link\" href='?controller=myaccount'>Admin</a></li>";  
            }
        }
        else{
            print "<li class=\"nav-item\"><a class=\"nav-link\" href='?controller=account&view=logout'>Register</a></li>";
            print "<li class=\"nav-item\"><a class=\"nav-link\" href='?controller=account&view=login'>Login</a></li>";
        }
    ?>
</ul>
    </nav>
