<?php
$l = new link();


$ecomodityid = "";
$elink = "";

if(isset($_POST['submit']))
{
    $l->filldata();

    $er = 0;
    if($l->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($l->link == "")
    {
        $er++;
        $elink = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($l->insert())
        {
            echo "link uploaded";
            $l = new link();
        }
        else{
            echo $l->error;
        }
    }
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $l->comodityid, $ecomodityid);

$html->text("link", $l->link, $elink);
$html->text("title", $l->title);
$html->submit();
$html->FormEnd();