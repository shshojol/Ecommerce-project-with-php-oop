<h2>comodity link Dasboard</h2>
<a href="?controller=comoditylinks&view=create">Create new</a><br>
<?php  
   $l = new link();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $l->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($l->select(), $controller);
?>
