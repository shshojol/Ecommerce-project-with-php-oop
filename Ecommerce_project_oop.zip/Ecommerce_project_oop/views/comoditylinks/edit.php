<?php
$l = new link();
$l->id = $_GET['id'];


$ecomodityid = "";
$elink = "";

if(isset($_POST['submit']))
{
    $l->filldata();

    $er = 0;
    if($l->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($l->link == "")
    {
        $er++;
        $elink = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($l->update())
        {
            echo "link updated";
        }
        else{
            echo $l->error;
        }
    }
}else{
    $l->selectbyid();
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $l->comodityid, $ecomodityid);

$html->text("link", $l->link, $elink);
$html->text("title", $l->title);
$html->submit();
$html->FormEnd();