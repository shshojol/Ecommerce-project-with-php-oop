<?php
$p = new priority();


$ename = "";
$edescription = "";

if(isset($_POST['submit']))
{
    $p->filldata();

    $er = 0;
    if($p->name == "")
    {
        $er++;
        $ename = "<span>Required</span>";
    }
    if($p->description == "")
    {
        $er++;
        $edescription = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($p->insert())
        {
            echo "data saved";
            $p = new priority();
        }
        else{
            mysqli_error($cn);
        }
    }
}

$html->FormStart();
$html->text("name", $p->name, $ename);
$html->textarea("description", $p->description, $edescription);
$html->submit();
$html->FormEnd();