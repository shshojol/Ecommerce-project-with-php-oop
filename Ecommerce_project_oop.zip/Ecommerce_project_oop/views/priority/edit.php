<?php
$p = new priority();
$p->id = $_GET['id'];

$ename = "";
$edescription = "";

if(isset($_POST['submit']))
{
    $p->filldata();

    $er = 0;
    if($p->name == "")
    {
        $er++;
        $ename = "<span>Required</span>";
    }
    if($p->description == "")
    {
        $er++;
        $edescription = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($p->update())
        {
            echo "data updated";
        }
        else{
            mysqli_error($cn);
        }
    }
}
else{
    $p->selectbyid();
}

$html->FormStart();
$html->text("name", $p->name, $ename);
$html->textarea("description", $p->description, $edescription);
$html->submit();
$html->FormEnd();