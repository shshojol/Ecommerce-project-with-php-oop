<h2>priority Dasboard</h2>
<a href="?controller=priority&view=create">Create gender</a><br>
<?php  
   $p = new priority();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $p->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($p->select(), $controller);
?>
