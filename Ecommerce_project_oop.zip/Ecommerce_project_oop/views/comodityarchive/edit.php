<?php
$ca = new comodityarchive();
$ca->comodityid = $_GET['id'];

$ecomodityid = "";
$euserid = "";

if(isset($_POST['submit']))
{
    $ca->filldata();

    $er = 0;
    if($ca->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($ca->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($ca->update())
        {
            echo "data updated";

        }
        else{
            echo $ca->error;
        }
    }
}else{
    $ca->selectbyid();
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $ca->comodityid, $ecomodityid);


$u = new users();
$html->select("userid", $u->select(), $ca->userid, $euserid);

$html->text("remarks", $ca->remarks);
$html->submit();
$html->FormEnd();