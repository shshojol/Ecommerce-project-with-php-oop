<h2>comodity archive Dasboard</h2>
<a href="?controller=comodityarchive&view=create">Create new</a><br>
<?php  
   $ca = new comodityarchive();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $ca->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($ca->select(), $controller);
?>
