<?php
$cp = new comoditypublish();


$ecomodityid = "";
$euserid = "";
$estartdate = "";
$eenddate = "";

if(isset($_POST['submit']))
{
    $cp->filldata();

    $er = 0;
    if($cp->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($cp->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($cp->startdate == "")
    {
        $er++;
        $estartdate = "<span>Required</span>";
    }
    if($cp->enddate == "")
    {
        $er++;
        $eenddate = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($cp->insert())
        {
            echo "comodity publish successfully";
            $cp = new comoditypublish();
        }
        else{
            echo $cp->error;
        }
    }
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $cp->comodityid, $ecomodityid);
$html->date("startdate", $cp->startdate, $estartdate);
$html->date("enddate", $cp->enddate, $eenddate);

$u = new users();
$html->select("userid", $u->select(), $cp->userid, $euserid);

$html->text("remarks", $cp->remarks);
$html->submit();
$html->FormEnd();