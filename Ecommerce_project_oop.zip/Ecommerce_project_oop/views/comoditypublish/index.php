<h2>comodity approved Dasboard</h2>
<a href="?controller=comoditypublish&view=create">Create new</a><br>
<?php  
   $cp = new comoditypublish();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $cp->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($cp->select(), $controller);
?>
