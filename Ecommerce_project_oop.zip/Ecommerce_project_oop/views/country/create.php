<?php
    $cnt = new country();

    $ename = "";
    if(isset($_POST['submit']))
    {
        $cnt->filldata();
        $er = 0;
        if($cnt->name == "")
        {
            $er++;
            $ename = "<span class='error'>Required</span>";
        }
        if($er == 0)
        {
           
            if($cnt->insert())
            {
                echo "<span class='success'>Country Created</span>";
                $cnt = new country();

            }
            else{
                echo "<span class='error'>".$cnt->error."</span>";
            }
        }
    }
?>

    
    <?php
        $html->FormStart();
        $html->text('name', $cnt->name, $ename);
        $html->submit('submit', 'create');
        $html->FormEnd();
    ?>

    
