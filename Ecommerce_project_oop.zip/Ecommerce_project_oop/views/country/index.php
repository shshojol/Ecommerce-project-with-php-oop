<h2>Country Dasboard</h2>
<a href="?controller=country&view=create">Create Country</a><br>
<?php  
   $cnt = new country();
  
   //srch button
   $search = "";
   if(isset($_POST['btnSearch']))
   {
        $search = $_POST['search'];
   }
   $html->FormStart();
   $html->text('search', $search);
   $html->submit('btnSearch', 'Search');
   $html->FormEnd();


   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $cnt->makeDelete($_GET['id']);
   }
   $cnt->search = $search;

    //show table data
    $html->table($cnt->select(), $controller);
?>
