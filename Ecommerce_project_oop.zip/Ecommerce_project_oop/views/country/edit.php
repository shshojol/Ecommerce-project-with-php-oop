<?php
$cnt = new country();
$cnt->id = $_GET['id'];

$ename="";

if(isset($_POST['submit']))
{
    $cnt->name = $_POST['name'];
    $er = 0;
    if($cnt->name == "")
    {
        $er++;
        $ename = "required";
    }
    if($er == 0)
    { 
        if($cnt->update())
        {
            echo 'data updated';
        }
        else{
            echo $cnt->error;
        } 
    }
}
else{
    $cnt->id = $_GET['id'];
    $cnt->selectById();
}
//form table
$html->FormStart();
$html->text('name', $cnt->name, $ename);
$html->submit('submit', 'Update');
$html->FormEnd();
