<?php
$ua = new uactive();


$euserid = "";



if(isset($_POST['submit']))
{
    $ua->filldata();

    $er = 0;
    if($ua->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($ua->insert())
        {
            echo "User Activated";
            $ua = new uactive();
        }
        else{
            echo "This User Already active";
        }
    }
}

$html->FormStart();

$u = new users();
$html->select("userid", $u->select(), $ua->userid, $euserid);
$html->text("ip", $ua->ip);

$html->submit();
$html->FormEnd();