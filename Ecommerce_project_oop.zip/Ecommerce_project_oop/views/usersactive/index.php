<h2>Active User Dasboard</h2>
<a href="?controller=usersactive&view=create">Create Active User</a><br>
<?php  
   $ua = new uactive();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $ua->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($ua->select(), $controller);
?>
