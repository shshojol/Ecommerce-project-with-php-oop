<h2>comodity discussion Dasboard</h2>
<a href="?controller=comoditydiscussion&view=create">Create new</a><br>
<?php  
   $cd = new comoditydiscussion();
  
   //table data deleted code
   if(isset($_GET['id']))
   {
        echo $cd->makeDelete($_GET['id']);
   }


    //show table data
    $html->table($cd->select(), $controller);
?>
