<?php
$cd = new comoditydiscussion();


$ecomodityid = "";
$euserid = "";
$ecomments = "";

if(isset($_POST['submit']))
{
    $cd->filldata();

    $er = 0;
    if($cd->comodityid == "0")
    {
        $er++;
        $ecomodityid = "<span>Required</span>";
    }
    if($cd->userid == "0")
    {
        $er++;
        $euserid = "<span>Required</span>";
    }
    if($cd->comments == "")
    {
        $er++;
        $ecomments = "<span>Required</span>";
    }
    if($er == 0)
    {
        if($cd->insert())
        {
            echo "data saved";
            $cd = new comoditydiscussion();
        }
        else{
            echo $cd->error;
        }
    }
}

$html->FormStart();


$c = new comodity();
$html->select("comodityid", $c->select(), $cd->comodityid, $ecomodityid);


$u = new users();
$html->select("userid", $u->select(), $cd->userid, $euserid);

$html->text("comments", $cd->comments, $ecomments);
$html->submit();
$html->FormEnd();