<?php

class htmlhelper{

    public function FormStart($method='post', $action='' , $attribute='')
    {
        echo "<form action='' method='".$method."' ".$attribute." enctype='multipart/form-data'>";
    }

    public function FormEnd()
    {
        echo "</form>";
    }

    public function text($name, $value = '', $error = '')
    {
        echo "
        <div class=\"form-group\">
            <label>".ucwords($name)."</label><br>
            <input type='text' class='form-control' name='".$name."' value='".$value."'><span class='error'>".$error."</span>
        </div>";
    }

    public function file($name,  $error = '')
    {
        echo "
        <div class=\"form-group\">
            <label>".ucwords($name)."</label><br>
            <input type='file' class='form-control' name='".$name."' ><span class='error'>".$error."</span>
        </div>";
    }

    public function password($name, $value = '', $error = '')
    {
        echo "
        <div class=\"form-group\">
            <label>".ucwords($name)."</label><br>
            <input type='password' class='form-control' name='".$name."' value='".$value."'><span class='error'>".$error."</span>
        </div>";
    }

    public function date($name, $value = '', $error = '')
    {
        echo "
        <div class=\"form-group\">
            <label>".ucwords($name)."</label><br>
            <input type='date' class='form-control' name='".$name."' value='".$value."'><span class='error'>".$error."</span>
        </div>";
    }

    public function textarea($name, $value = '', $error = '')
    {
        echo "
        <div class=\"form-group\">
            <label>".ucwords($name)."</label><br>
            <textarea  class='form-control' name='".$name."'>".$value."</textarea><span class='error'>".$error."</span>
        </div>";
    }

    public function submit($submit="submit", $value="submit")
    {
        echo "<input type='submit' class=\"btn btn-primary\" name='".$submit."' value='".ucwords($value)."'>";
    }

    public function table($table, $controller, $replaceColumn = "", $replaceValue = "")
    {
    echo "<table class=\"table table-dark table-hover\">";
    $i=0;
        foreach($table as $row)
        {
            //show table title
            echo "<thead>";
                echo "<tr>";
                    if($i == 0)
                    {
                        foreach($row as $k=>$v)
                        {
                            if(strtolower($k) != 'id')
                                echo "<th>".ucwords($k)."</th>";
                        }
                        echo "<th>#</th>";
                    }
                echo "</tr>";
            echo "</thead>";

            
            //show table data
            echo "<tbody>";
                echo "<tr>";
                    foreach($row as $k=>$v)
                    {   
                        if(strtolower($k) != 'id')
                        {
                            if($k == $replaceColumn)
                            {
                                echo "<td>".str_replace("#replace#", $v, $replaceValue)."</td>";
                            }
                            else{
                                echo "<td>".strip_tags($v)."</td>";
                            }   
                        }
                        
                    }
                            echo "<td>
                                    <a href='?controller=".$controller."&view=edit&id=".$row['id']."'>Edit</a>
                                    <a href='?controller=".$controller."&id=".$row['id']."'>| Delete</a>
                                </td>";
                echo "</tr>";
            echo "</tbody>";
            $i++;
        }
    echo "</table>";
    }


    function select($name, $table, $value="", $error="")
    {
        echo '<div class=\"form-group\">';
        echo "<label>".$name."</label><br>";
        echo "<select name='".$name."' class=\"form-control\">
                <option value='0'>select</option>";
                
                foreach($table as $row)
                {
                    if($row['id'] == $value)
                    {
                        echo "<option value='".$row['id']."' selected>".$row['name']."</option>";
                    }
                    else{
                        echo "<option value='".$row['id']."'>".$row['name']."</option>";
                    }
                }

        echo "</select><span class='error'>".$error."</span><br>";
        echo "</div>";
    }

    public function error($msg)
    {
        echo "<span class='error'>".$msg."</span>";
    }

    public function errorBlock($msg)
    {
        echo "<div class='error'>".$msg."</div>";
    }

    public function success($msg)
    {
        echo "<span class='success'>".$msg."</span>";
    }

    public function successBlock($msg)
    {
        echo "<div class='success'>".$msg."</div>";
    }
}