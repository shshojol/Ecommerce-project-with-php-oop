<?php

class country extends base
{
    public $id;
    public $name;

    public function insert()
    {
        $sql = "insert into country(name) values ('".$this->name."')";
        return $this->execute($sql);
    }

    public function update()
    {
        
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update country set name = '".$this->name."' where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from country where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectById()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, name from country where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, name from country";
        if($this->search != "")
        {
            $sql .= " where name like '%".$this->search."%'";
        }
        return $this->executeTable($sql);
    }
}