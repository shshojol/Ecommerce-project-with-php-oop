<?php
class users extends base
{
    public $id;
    public $name;
    public $contact;
    public $email; 
    public $password; 
    public $dob;
    public $genderid; 
    public $address; 
    public $cityid; 
    public $image; 
    public $type;
    public $createdate; 
    public $createip;

    public function insert()
    {
        $sql = "insert into users (name, contact, email, password, dob, genderid, address, cityid, image, type, createdate, createip
        ) values ('".$this->name."', '".$this->contact."' , '".$this->email."', password('".$this->password."'),
         '".$this->dob."', ".$this->genderid.", '".$this->address."', ".$this->cityid.", 
         '".$this->image."', '".$this->type."', '".$this->createdate."', '".$this->createip."')";

        return $this->execute($sql);
    }

    public function update()
    {
        $sql = "update users set name = '".$this->contact."', 
        contact = '".$this->contact."', 
        email = '".$this->email."', 
        password = password('".$this->password."'), 
        dob = '".$this->dob."', 
        genderid = ".$this->genderid.",
        address = '".$this->address."',
        cityid = ".$this->cityid.", 
        image = '".$this->image."', 
        type = '".$this->type."', 
        createdate = '".$this->createdate."', 
        createip = '".$this->createip."' where id = ".$this->id;

        return $this->execute($sql);
    }

    public function delete()
    {
        $sql = "delete from users where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectById()
    {
        $sql = "select id, name, contact, email, password, dob, genderid, 
        address, cityid, image, type, createdate, createip
        from users where id = ".$this->id;
        $this->fillObject($sql);
    }
    public function login()
    {
        $sql = "select id, name, contact, email, password, dob, genderid, 
        address, cityid, image, type, createdate, createip
        from users where email = '".$this->email."' and password = password('".$this->password."')";
        return $this->fillObject($sql);
    }
   

    public function select()
    {
        $a = array();
        $sql = "select u.id, u.name, u.contact, u.email,  u.dob, gnd.name as gender, u.address, ct.name as city, cn.name as country, u.image, u.type, u.createdate, u.createip
        from users as u
        left join gender as gnd on u.genderid =  gnd.id 
        left join city as ct on u.cityid = ct.id
        left join country as cn on ct.countryid = cn.id";
        if($this->search != "")
        {
            $sql .= " where (u.name like '%".$this->search."%' or u.contact '%".$this->search."%'
            or u.email '%".$this->search."%' )";
        }
        if($this->genderid > 0)
        {
            $sql .= " and gnd.id = ".$this->genderid;
        }
        if($this->cityid > 0)
        {
            $sql .= " and ct.id = ".$this->cityid;
        }


        return $this->executeTable($sql);
    }

}