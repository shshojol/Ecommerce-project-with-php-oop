<?php

class usersrating extends base{
    public $userid;
    public $ratebyuserid;
    public $datetime;
    public $rating;

    
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into usersrating (userid, ratebyuserid, rating)
        values('".$this->userid."', '".$this->ratebyuserid."', '".$this->rating."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update usersrating set userid = '".$this->userid."',
         ratebyuserid = '".$this->ratebyuserid."',
         rating = '".$this->rating."'
         where userid = ".$this->userid;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from usersrating where userid = ". $this->userid;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select userid, ratebyuserid, rating from usersrating where userid = ".$this->userid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "SELECT u.id, u.name as user, u1.name as rateby, ur.datetime, ur.rating
        from usersrating as ur
        LEFT JOIN users as u on ur.userid = u.id
        LEFT join users as u1 on ur.ratebyuserid = u1.id where u.id > 0";

        if($this->userid > 0 )
        {
            $sql .= " and u.id = ".$this->userid;
        }
        return $this->executeTable($sql);
    }
}

