<?php
class comodity extends base
{
    public $id;
    public $title;
    public $description;
    public $conditionid; 
    public $locationid; 
    public $priorityid;
    public $datetime; 
    public $userid; 
    public $ip; 
  

    public function insert()
    {
        $sql = "insert into comodity (title, description, conditionid, locationid, priorityid, userid, ip
        ) values ('".$this->title."', '".$this->description."' , '".$this->conditionid."',
         '".$this->locationid."', ".$this->priorityid.", ".$this->userid.", 
         '".$this->ip."')";

        return $this->execute($sql);
    }

    public function update()
    {
        $sql = "update comodity set title = '".$this->title."', 
        description = '".$this->description."', 
        conditionid = '".$this->conditionid."', 
        priorityid = '".$this->priorityid."', 
        locationid = ".$this->locationid.",
        userid = '".$this->userid."',
        ip = ".$this->ip." where id = ".$this->id;

        return $this->execute($sql);
    }

    public function delete()
    {
        $sql = "delete from comodity where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectByid()
    {
        $sql = "select id,title, description, conditionid, locationid, priorityid, userid, ip
        from comodity where id = ".$this->id;
        return $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select  c.id, c.title as name, c.description,
         cc.name as 'condition', loc.name  as location, p.name as priority,
          c.datetime,
        u.name as user,c.userid, c.ip
        from comodity as c 
        LEFT JOIN comoditycondition as cc on c.conditionid = cc.id
        LEFT JOIN location as loc on c.locationid = loc.id
        LEFT join priority as p on c.priorityid = p.id
        LEFT join users as u on c.userid = u.id where c.id > 0";

        if($this->id > 0)
        {
            $sql .= " and c.id = ".$this->id;
        }

        if($this->userid > 0)
        {
         
            $sql .= " and c.id in (select comodityid from messages where userid = ".$this->userid.")";
        }



        return $this->executeTable($sql);
    }

}