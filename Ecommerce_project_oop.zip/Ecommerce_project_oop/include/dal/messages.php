<?php

class messages extends base{
    public $id;
    public $comodityid;
    public $userid;
    public $datetime;
    public $message;
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into messages (comodityid, userid, message)
         values('".$this->comodityid."', '".$this->userid."', '".$this->message."')";
        return $this->execute($sql);

    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update messages set 
        comodityid = '".$this->comodityid."', userid = '".$this->userid."', 
        message = '".$this->message."' where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from messages where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, comodityid, userid, message from messages where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select ca.id, c.title as name, u.name as user, ca.datetime, ca.message
        from messages as ca 
        LEFT join comodity as c on ca.comodityid = c.id 
        LEFT join users as u on ca.userid = u.id where ca.comodityid > 0";
        if($this->comodityid > 0)
        {
            $sql .= " and ca.comodityid = ". $this->comodityid;
        }
        if($this->userid > 0)
        {
            $sql .= " and (ca.id = ".$this->userid." or c.userid = ".$this->userid.")";
        }

        return $this->executeTable($sql);
    }
}

