<?php

class link extends base{
    public $id;
    public $comodityid;
    public $link;
    public $title;

    
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into commoditylinks (comodityid, link, title)
        values('".$this->comodityid."', '".$this->link."', '".$this->title."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update commoditylinks set comodityid = '".$this->comodityid."',
         link = '".$this->link."',
         title = '".$this->title."'
         where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from commoditylinks where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select comodityid, link, title from commoditylinks where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select l.id, c.title as comodity, l.link, l.title
        from commoditylinks as l 
        LEFT join comodity as c on l.comodityid = c.id";
        return $this->executeTable($sql);
    }
}

