<?php

class city extends base{
    public $id;
    public $name;
    public $countryid;
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into city (name, countryid) values('".$this->name."', '".$this->countryid."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update city set name = '".$this->name."', countryid= ".$this->countryid." where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from city where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, name, countryid from city where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select c.id, c.name, cn.name as country
        from city as c left join country as cn on c.countryid=cn.id where c.id > 0";
        if($this->search != "")
        {
            $sql .= " and c.name like '%".$this->search."%'";
        }
        if($this->countryid > 0)
        {
            $sql .= " and cn.id like '%".$this->countryid."%'";
        }
        return $this->executeTable($sql);
    }
}

