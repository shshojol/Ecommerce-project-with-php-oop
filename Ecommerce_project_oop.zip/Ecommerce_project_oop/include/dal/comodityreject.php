<?php

class comodityreject extends base{
    public $comodityid;
    public $userid;
    public $datetime;
    public $remarks;
   

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into comodityreject (comodityid, userid, remarks)
        values('".$this->comodityid."',".$this->userid.", '".$this->remarks."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update comodityreject set comodityid = '".$this->comodityid."',
         remarks = ".$this->remarks.",
         userid = '".$this->userid."'
         where comodityid = ".$this->comodityid;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from comodityreject where comodityid = ". $this->comodityid;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select comodityid, remarks, userid from comodityreject where comodityid = ".$this->comodityid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select c.id, c.title as name , u.name as user , cr.datetime, cr.remarks 
        from comodityreject as cr
        LEFT join comodity as c on cr.comodityid = c.id
        LEFT JOIN users as u on cr.userid = u.id";
        return $this->executeTable($sql);
    }
}

