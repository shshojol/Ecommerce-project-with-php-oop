<?php

class comoditydiscussion extends base{
    public $id;
    public $comodityid;
    public $userid;
    public $datetime;
    public $comments;
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into commoditydiscussion (comodityid, userid, comments)
         values('".$this->comodityid."', '".$this->userid."', '".$this->comments."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update commoditydiscussion set 
        comodityid = '".$this->comodityid."', userid = '".$this->userid."', 
        comments = ".$this->comments." where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from commoditydiscussion where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select comodityid, userid, comments from commoditydiscussion where userid = ".$this->userid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select c.id, c.title as name, u.name as user, ca.datetime, ca.comments
        from commoditydiscussion as ca 
        LEFT join comodity as c on ca.comodityid = c.id 
        LEFT join users as u on ca.userid = u.id";
        return $this->executeTable($sql);
    }
}

