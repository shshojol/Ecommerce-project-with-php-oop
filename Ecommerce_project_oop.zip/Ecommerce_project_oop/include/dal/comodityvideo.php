<?php

class comodityvideo extends base{
    public $id;
    public $comodityid;
    public $videolink;
    public $title;

    
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into commodityvedio (comodityid, videolink, title)
        values('".$this->comodityid."', '".$this->videolink."', '".$this->title."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update commodityvedio set comodityid = '".$this->comodityid."',
        videolink = '".$this->videolink."',
         title = '".$this->title."'
         where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from commodityvedio where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, comodityid, videolink, title from commodityvedio where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select l.id, c.title as comodity, l.videolink, l.title
        from commodityvedio as l 
        LEFT join comodity as c on l.comodityid = c.id";
        return $this->executeTable($sql);
    }
}

