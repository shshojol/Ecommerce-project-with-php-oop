<?php

class usersblock extends base{
    public $userid;
    public $datefrom;
    public $dateto;
    public $remarks;
    public $adminuserid;
    
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into usersblock (userid, datefrom, dateto, remarks, adminuserid)
        values('".$this->userid."', '".$this->datefrom."', '".$this->dateto."', ".$this->remarks.", '".$this->adminuserid."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update usersblock set userid = '".$this->userid."',
         datefrom = '".$this->datefrom."',
         dateto = '".$this->dateto."',
         remarks = ".$this->remarks.",
         adminuserid = '".$this->adminuserid."'
         where userid = ".$this->userid;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from usersblock where userid = ". $this->userid;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select userid, datefrom, dateto, remarks, adminuserid from usersblock where userid = ".$this->userid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select u.id, u.name as user, ub.datefrom, ub.dateto, ub.remarks, u1.name as admin
        from usersblock as ub
        LEFT JOIN users as u on ub.userid = u.id 
        left join users as u1 on ub.adminuserid = u1.id";
        return $this->executeTable($sql);
    }
}

