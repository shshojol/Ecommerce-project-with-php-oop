<?php

class comoditycondition extends base{
    public $id;
    public $name;
    public $description;
    public $rating;
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into comoditycondition (name, description, rating) values('".$this->name."', '".$this->description."', ".$this->rating.")";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update comoditycondition set name = '".$this->name."', description = '".$this->description."', rating = ".$this->rating." where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from comoditycondition where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, name, description, rating from comoditycondition where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, name, description, rating from comoditycondition";
        return $this->executeTable($sql);
    }
}

