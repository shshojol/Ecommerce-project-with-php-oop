<?php

class usersverified extends base{
    public $userid;
    public $method;
    public $datetime;
    public $adminuserid;

    
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into usersverified (userid, method, adminuserid)
        values('".$this->userid."', '".$this->method."', '".$this->adminuserid."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update usersverified set userid = '".$this->userid."',
         method = '".$this->method."',
         adminuserid = '".$this->adminuserid."'
         where userid = ".$this->userid;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from usersverified where userid = ". $this->userid;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select userid, method, adminuserid from usersverified where userid = ".$this->userid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "SELECT u.id, u.name as user, uv.method, uv.datetime, u1.name as admin
        from usersverified as uv
        LEFT JOIN users as u on uv.userid = u.id
        LEFT join users as u1 on uv.adminuserid = u1.id";
        return $this->executeTable($sql);
    }
}

