<?php

class priority extends base{
    public $id;
    public $name;
    public $description;
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into priority (name, description) values('".$this->name."', '".$this->description."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update priority set name = '".$this->name."', description = '".$this->description."' where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from priority where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, name, description from priority where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, name, description from priority";
        return $this->executeTable($sql);
    }
}

