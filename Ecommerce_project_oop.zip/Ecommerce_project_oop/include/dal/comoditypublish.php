<?php

class comoditypublish extends base{
    public $comodityid;
    public $startdate;
    public $enddate;
    public $userid;
    public $remarks;
   

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into comoditypublish (comodityid, startdate, enddate, userid, remarks)
        values('".$this->comodityid."', '".$this->startdate."', '".$this->enddate."', ".$this->userid.", '".$this->remarks."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update comoditypublish set comodityid = '".$this->comodityid."',
         startdate = '".$this->startdate."',
         enddate = '".$this->enddate."',
         remarks = ".$this->remarks.",
         userid = '".$this->userid."'
         where comodityid = ".$this->comodityid;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from comoditypublish where comodityid = ". $this->comodityid;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select comodityid, startdate, enddate, remarks, userid from comoditypublish where comodityid = ".$this->comodityid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select c.id, c.title as name, cp.startdate, cp.enddate, u.name as user, cp.remarks 
        from comoditypublish as cp
        LEFT JOIN comodity as c on cp.comodityid = c.id 
        LEFT join users as u on cp.userid = u.id";
        return $this->executeTable($sql);
    }
}

