<?php

class loginhistory extends base{
    public $userid;
    public $datetime;
    public $ip;
    
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into loginhistory (userid, ip) values('".$this->userid."', '".$this->ip."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update loginhistory set userid = '".$this->userid."', ip = '".$this->ip."' where userid = ".$this->userid;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from loginhistory where userid = ". $this->userid;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select userid, datetime, ip from loginhistory where userid = ".$this->userid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select u.id, u.name, u.email, u.contact, ua.datetime, ua.ip
        from loginhistory as ua
        LEFT JOIN users as u on ua.userid = u.id";
        return $this->executeTable($sql);
    }
}

