<?php

class comodityprice extends base{
    public $comodityid;
    public $regularprice;
    public $price;

    
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into comodityprice (comodityid, regularprice, price)
        values('".$this->comodityid."', '".$this->regularprice."', '".$this->price."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update comodityprice set comodityid = '".$this->comodityid."',
         regularprice = '".$this->regularprice."',
         price = '".$this->price."'
         where comodityid = ".$this->comodityid;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from comodityprice where comodityid = ". $this->comodityid;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select comodityid, regularprice, price from comodityprice where comodityid = ".$this->comodityid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select c.id, c.title as name, cp.regularprice, cp.price 
        from comodityprice as cp
        left JOIN comodity as c on cp.comodityid = c.id where c.id > 0";

        if($this->comodityid > 0)
        {
            $sql .= " and c.id = ". $this->comodityid;
        }
     
        return $this->executeTable($sql);
    }
}

