<?php

class comodityapproved extends base{
    public $comodityid;
    public $userid;
    public $datetime;
    public $remarks;
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into comodityapproved (comodityid, userid, remarks)
         values('".$this->comodityid."', '".$this->userid."', '".$this->remarks."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update comodityapproved set comodityid = '".$this->comodityid."', userid = '".$this->userid."', 
        remarks = ".$this->remarks." where comodityid = ".$this->comodityid;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from comodityapproved where comodityid = ". $this->comodityid;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select comodityid, userid, remarks from comodityapproved where comodityid = ".$this->comodityid;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select c.id, c.title as name, u.name as user, ca.datetime, ca.remarks
        from comodityapproved as ca 
        LEFT join comodity as c on ca.comodityid = c.id 
        LEFT join users as u on ca.userid = u.id";
        return $this->executeTable($sql);
    }
}

