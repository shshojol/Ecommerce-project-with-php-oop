<?php

class location extends base{
    public $id;
    public $name;
    public $cityid;
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into location (name, cityid) values('".$this->name."', '".$this->cityid."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update location set name = '".$this->name."', cityid = '".$this->cityid."' where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from location where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select id, name, cityid from location where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "SELECT l.id, l.name, c.name as city 
        from location as l
        LEFT join city as c on l.cityid = c.id";
        return $this->executeTable($sql);
    }
}

