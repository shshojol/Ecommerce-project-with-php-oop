<?php

class image extends base{
    public $id;
    public $comodityid;
    public $image;
    public $title;

    
    

    public function insert()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "insert into commodityimage (comodityid, image, title)
        values('".$this->comodityid."', '".$this->image."', '".$this->title."')";
        return $this->execute($sql);
    }

    public function update()
    {   
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "update commodityimage set comodityid = '".$this->comodityid."',
         image = '".$this->image."',
         title = '".$this->title."'
         where id = ".$this->id;
        return $this->execute($sql);
    }

    public function delete()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "delete from commodityimage where id = ". $this->id;
        return $this->execute($sql);
    }

    public function selectbyid()
    {
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select comodityid, image, title from commodityimage where id = ".$this->id;
        $this->fillObject($sql);
    }

    public function select()
    {
        $a = array();
        $cn = mysqli_connect("localhost", "root", "", "bitm2");
        $sql = "select ci.id, c.title as name, ci.image, ci.title 
        from commodityimage as ci
        left JOIN comodity as c on ci.comodityid = c.id where c.id > 0";

        if($this->comodityid > 0)
        {
            $sql .= " and c.id = ".$this->comodityid;
        }
       
        return $this->executeTable($sql);
    }
}

