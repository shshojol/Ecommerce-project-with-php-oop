-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2021 at 09:27 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bitm2`
--

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `countryid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `name`, `countryid`) VALUES
(1, 'dhaka', 1),
(2, 'Khulna', 1),
(4, 'chittagang', 1),
(35, 'Delhi', 2);

-- --------------------------------------------------------

--
-- Table structure for table `commodityarchive`
--

CREATE TABLE `commodityarchive` (
  `comodityid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `remarks` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commodityarchive`
--

INSERT INTO `commodityarchive` (`comodityid`, `userid`, `datetime`, `remarks`) VALUES
(1, 3, '2020-05-31 18:58:00', '10'),
(5, 1, '2020-05-31 18:50:40', '5'),
(6, 4, '2021-04-03 02:06:45', '10');

-- --------------------------------------------------------

--
-- Table structure for table `commoditydiscussion`
--

CREATE TABLE `commoditydiscussion` (
  `id` int(11) NOT NULL,
  `comodityid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `comments` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commoditydiscussion`
--

INSERT INTO `commoditydiscussion` (`id`, `comodityid`, `userid`, `datetime`, `comments`) VALUES
(1, 4, 1, '2020-05-28 18:01:17', 'good'),
(3, 5, 4, '2020-05-31 18:48:03', 'very good'),
(5, 1, 1, '2020-05-31 18:48:29', 'not good'),
(6, 4, 1, '2021-04-03 02:13:25', 'nice');

-- --------------------------------------------------------

--
-- Table structure for table `commodityimage`
--

CREATE TABLE `commodityimage` (
  `id` int(11) NOT NULL,
  `comodityid` int(11) NOT NULL,
  `image` varchar(500) NOT NULL,
  `title` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commodityimage`
--

INSERT INTO `commodityimage` (`id`, `comodityid`, `image`, `title`) VALUES
(12, 1, '133188-v4-oppo-f11-mobile-phone-large-1.jpg', 'mobile image'),
(13, 1, 'z92banner.png', 'mobile image 2'),
(14, 7, 'istockphoto-484719630-612x612.jpg', 'charger'),
(15, 5, 'Laptop-computer.jpg', 'computer'),
(16, 4, 'Vision-43quot-LED-TV-X20-Pro-Smart.jpg', 'tv'),
(18, 6, 'depositphotos_6367048-stock-photo-panama-hat.jpg', 'hat'),
(20, 9, '5718897981_10faa45ac3_b-640x624.jpg', 'cycle'),
(21, 1, '07ml3nh3QrzTLZ9UycfQQB2-33..1588361730.jpg', ''),
(22, 1, 'landing-page-image-01.jpg', ''),
(23, 21, '', 'headphone1'),
(24, 21, '', 'headphone2'),
(25, 22, '4-original-image.jpg', 'abc'),
(26, 22, '983794168.jpg', 'abcd'),
(27, 23, 'pexels-photo-697243.jpeg', 'abcd'),
(28, 23, 'image.jpg', 'abcd'),
(29, 24, 'pexels-photo-697243.jpeg', 'abcd'),
(30, 24, 'image.jpg', 'abcd');

-- --------------------------------------------------------

--
-- Table structure for table `commoditylinks`
--

CREATE TABLE `commoditylinks` (
  `id` int(11) NOT NULL,
  `comodityid` int(11) NOT NULL,
  `link` varchar(200) NOT NULL,
  `title` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commoditylinks`
--

INSERT INTO `commoditylinks` (`id`, `comodityid`, `link`, `title`) VALUES
(1, 5, 'www.links.com', 'go here'),
(2, 4, 'www.link.com', 'click here ok'),
(3, 7, 'www.charger.com', 'charger here click'),
(4, 1, 'www.link.com', 'click here'),
(5, 16, 'bat.com', 'anc.com'),
(6, 16, 'fsf', 'asdf'),
(7, 17, 'fsf', ''),
(8, 17, 'fsf', ''),
(9, 18, 'fsf', ''),
(10, 18, 'fsf', ''),
(11, 19, 'bat.com', 'bat'),
(12, 19, 'ball.com', 'ball'),
(13, 20, 'bat.com', 'bat'),
(14, 20, 'ball.com', 'ball'),
(15, 21, 'abc.com', 'abc'),
(16, 22, 'bat.com', 'bat'),
(17, 23, 'bat.com', 'bat'),
(18, 24, 'bat.com', 'bat');

-- --------------------------------------------------------

--
-- Table structure for table `commodityvedio`
--

CREATE TABLE `commodityvedio` (
  `id` int(11) NOT NULL,
  `comodityid` int(11) NOT NULL,
  `videolink` varchar(500) NOT NULL,
  `title` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commodityvedio`
--

INSERT INTO `commodityvedio` (`id`, `comodityid`, `videolink`, `title`) VALUES
(3, 1, 'www.video', 'click here'),
(4, 4, 'www.video.com', 'charger here click');

-- --------------------------------------------------------

--
-- Table structure for table `comodity`
--

CREATE TABLE `comodity` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `conditionid` int(11) NOT NULL,
  `locationid` int(11) NOT NULL,
  `priorityid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `userid` int(11) NOT NULL,
  `ip` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comodity`
--

INSERT INTO `comodity` (`id`, `title`, `description`, `conditionid`, `locationid`, `priorityid`, `datetime`, `userid`, `ip`) VALUES
(1, 'mobile', 'new', 1, 1, 1, '2020-05-24 16:45:30', 3, '6856'),
(4, 'Tv', 'not bad', 1, 1, 1, '2020-05-24 17:37:52', 4, '20'),
(5, 'computer', 'used', 1, 1, 1, '2020-05-26 21:39:10', 4, '20'),
(6, 'hat', 'this is like hair', 5, 1, 1, '2020-06-04 16:53:17', 1, '20.02'),
(7, 'charger', '1 pcs ase', 5, 6, 4, '2021-04-01 01:38:33', 4, '102.22510.265'),
(9, 'cycle', 'bi cycle', 5, 3, 4, '2021-04-21 04:37:36', 4, '10.10'),
(10, 'need a smart jahru', 'NA', 5, 1, 1, '2021-04-27 02:51:28', 15, '::1'),
(11, 'neeed watch', 'NA', 1, 5, 4, '2021-04-27 03:02:11', 15, '::1'),
(12, 'need sunglass', 'na', 1, 4, 6, '2021-04-27 03:06:39', 15, '::1'),
(13, 'shirt', 'NA', 5, 6, 5, '2021-04-27 03:08:39', 15, '::1'),
(14, 'Pant', 'NA', 1, 1, 3, '2021-04-27 03:12:16', 15, '::1'),
(15, 'T shirt', 'NA', 5, 5, 3, '2021-04-27 03:19:17', 15, '::1'),
(16, 'Array', 'NA', 5, 3, 3, '2021-04-28 23:09:21', 15, '::1'),
(17, 'Array', 'na', 1, 5, 4, '2021-04-28 23:21:39', 15, '::1'),
(18, 'Array', 'na', 1, 5, 4, '2021-04-29 01:27:51', 15, '::1'),
(19, 'bag', 'na', 1, 3, 6, '2021-04-29 01:28:56', 15, '::1'),
(20, 'bag', 'na', 1, 3, 6, '2021-04-29 01:56:13', 15, '::1'),
(21, 'headphone', 'NA', 1, 3, 4, '2021-04-29 02:16:12', 15, '::1'),
(22, 'socks', 'na', 1, 4, 4, '2021-04-29 02:23:16', 15, '::1'),
(23, 'flower', 'na', 1, 6, 1, '2021-04-29 02:27:55', 15, '::1'),
(24, 'flower', 'na', 1, 6, 1, '2021-04-29 02:28:23', 15, '::1');

-- --------------------------------------------------------

--
-- Table structure for table `comodityapproved`
--

CREATE TABLE `comodityapproved` (
  `comodityid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `remarks` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comodityapproved`
--

INSERT INTO `comodityapproved` (`comodityid`, `userid`, `datetime`, `remarks`) VALUES
(1, 3, '2020-05-26 22:24:13', '5'),
(4, 4, '2020-05-26 22:24:13', '5'),
(5, 1, '2020-06-04 17:01:53', '5'),
(6, 1, '2020-06-04 17:03:58', '1');

-- --------------------------------------------------------

--
-- Table structure for table `comoditycondition`
--

CREATE TABLE `comoditycondition` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comoditycondition`
--

INSERT INTO `comoditycondition` (`id`, `name`, `description`, `rating`) VALUES
(1, 'Used A+', 'Normal sign of use, full functional', 8),
(5, 'like new', 'Just unpacked for test', 9);

-- --------------------------------------------------------

--
-- Table structure for table `comodityprice`
--

CREATE TABLE `comodityprice` (
  `comodityid` int(11) NOT NULL,
  `regularprice` float NOT NULL,
  `price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comodityprice`
--

INSERT INTO `comodityprice` (`comodityid`, `regularprice`, `price`) VALUES
(5, 2500, 500),
(1, 100, 500),
(6, 2000, 600),
(4, 800, 300),
(7, 950, 200),
(9, 3500, 2500),
(13, 125, 25),
(15, 1250, 2550),
(16, 2000, 2500),
(17, 125, 600),
(18, 125, 600),
(19, 320, 558),
(20, 320, 558),
(21, 1250, 1000),
(22, 1250, 2500),
(23, 2000, 2550),
(24, 2000, 2550);

-- --------------------------------------------------------

--
-- Table structure for table `comoditypublish`
--

CREATE TABLE `comoditypublish` (
  `comodityid` int(11) NOT NULL,
  `startdate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL,
  `userid` int(11) NOT NULL,
  `remarks` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comoditypublish`
--

INSERT INTO `comoditypublish` (`comodityid`, `startdate`, `enddate`, `userid`, `remarks`) VALUES
(1, '2020-05-05', '2020-05-20', 4, '8'),
(4, '2020-05-08', '2020-05-22', 1, '5'),
(5, '0000-00-00', '0000-00-00', 3, '10'),
(6, '2021-04-01', '2021-04-22', 4, '9');

-- --------------------------------------------------------

--
-- Table structure for table `comodityreject`
--

CREATE TABLE `comodityreject` (
  `comodityid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `remarks` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comodityreject`
--

INSERT INTO `comodityreject` (`comodityid`, `userid`, `datetime`, `remarks`) VALUES
(1, 1, '2020-05-28 17:23:38', '5'),
(4, 3, '2020-05-28 17:36:55', '1'),
(5, 1, '2020-05-28 17:36:15', '56'),
(6, 3, '2021-04-03 01:06:46', '5'),
(7, 1, '2021-04-03 01:06:20', '10');

-- --------------------------------------------------------

--
-- Table structure for table `comoditysold`
--

CREATE TABLE `comoditysold` (
  `comodityid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `remarks` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comoditysold`
--

INSERT INTO `comoditysold` (`comodityid`, `userid`, `datetime`, `remarks`) VALUES
(1, 4, '2020-05-28 17:48:49', '5'),
(4, 3, '2020-05-28 17:47:55', '10'),
(6, 3, '2021-04-03 01:18:33', '10'),
(7, 3, '2021-04-03 01:18:50', '6');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`id`, `name`) VALUES
(45, 'Australia'),
(1, 'Bangladesh'),
(2, 'india'),
(48, 'sri Lanka');

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`id`, `name`, `description`) VALUES
(1, 'male', 'dsfsaf'),
(12, 'female', 'this is'),
(15, 'Other', 'N?/c n/c');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `cityid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `cityid`) VALUES
(1, 'kallanpur', 1),
(3, 'mirpur', 1),
(4, 'changa', 2),
(5, 'new market', 4),
(6, 'dhanmondi 32', 1);

-- --------------------------------------------------------

--
-- Table structure for table `loginhistory`
--

CREATE TABLE `loginhistory` (
  `userid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `ip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `loginhistory`
--

INSERT INTO `loginhistory` (`userid`, `datetime`, `ip`) VALUES
(3, '2020-05-23 01:45:50', '20'),
(4, '2020-05-23 01:46:23', '20.02'),
(4, '2020-05-23 01:46:30', '20.02');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `comodityid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `message` varchar(500) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `comodityid`, `userid`, `message`, `datetime`) VALUES
(1, 1, 1, 'good good', '2020-06-04 13:04:03'),
(2, 1, 3, 'not good work', '2020-06-04 13:08:12'),
(3, 5, 3, 'not good work', '2020-06-04 13:08:25'),
(4, 4, 4, 'not good work', '2020-06-04 13:08:36'),
(5, 4, 1, 'not good work', '2021-04-03 02:24:04'),
(6, 1, 13, 'ok hurry', '2021-04-17 17:31:53'),
(7, 7, 13, 'OMG how sweet', '2021-04-17 23:16:16'),
(8, 7, 13, 'OMG how sweet', '2021-04-17 23:16:27'),
(9, 7, 13, 'OMG how sweet', '2021-04-18 00:04:37'),
(10, 7, 13, 'OMG how sweet', '2021-04-18 00:04:56'),
(11, 5, 13, 'ok', '2021-04-18 00:05:57'),
(12, 5, 13, 'ok', '2021-04-18 00:06:04'),
(13, 5, 13, 'ok', '2021-04-18 00:06:08'),
(19, 1, 13, ' its good', '2021-04-18 00:10:48'),
(21, 1, 13, 'bad producet', '2021-04-18 00:16:26'),
(22, 4, 14, 'koi yui', '2021-04-20 23:54:13'),
(23, 4, 14, 'basay', '2021-04-20 23:58:44'),
(24, 4, 14, 'basay', '2021-04-21 00:06:58'),
(25, 7, 14, 'price koto', '2021-04-21 00:07:49'),
(26, 7, 14, 'price koto', '2021-04-21 00:07:59'),
(27, 6, 14, 'not goosd', '2021-04-21 00:09:11'),
(28, 6, 14, 'not goosd', '2021-04-21 00:14:06'),
(29, 1, 14, 'sizw avaialabkle', '2021-04-21 00:31:06'),
(31, 1, 4, 'no sir', '2021-04-23 03:37:28'),
(32, 1, 4, 'no sir', '2021-04-23 03:37:37'),
(33, 4, 4, 'mathe ay', '2021-04-23 03:38:45'),
(34, 4, 4, 'mathe ay', '2021-04-23 03:38:50'),
(35, 5, 4, 'price koto?', '2021-04-23 03:39:42');

-- --------------------------------------------------------

--
-- Table structure for table `priority`
--

CREATE TABLE `priority` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `priority`
--

INSERT INTO `priority` (`id`, `name`, `description`) VALUES
(1, 'Very Emargency', 'within 6 hour'),
(3, 'Emergency', 'within 12 hour'),
(4, 'High ', 'Within 1 day'),
(5, 'Medium', 'Needed but not urgent'),
(6, 'Low', 'need ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `dob` date DEFAULT NULL,
  `genderid` int(11) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `cityid` int(11) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `type` varchar(2) DEFAULT NULL,
  `createdate` datetime DEFAULT current_timestamp(),
  `createip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `contact`, `email`, `password`, `dob`, `genderid`, `address`, `cityid`, `image`, `type`, `createdate`, `createip`) VALUES
(1, 'kodom ali', '01359752644', 'kodom@yahoo.com', '*98D91DD16F365514D461CCE6DE0E7322B12819C2', '0000-00-00', 1, 'NA', 1, '', 'A', '0000-00-00 00:00:00', '128.25.25'),
(3, 'shojol', '01682623426', 'shojol@gmail.com', '*BD5E64C5EF04C3EC42D63B6EB21120CF509730A6', '1995-12-20', 1, 'NA', 1, 'noimage.png', 'A', '0000-00-00 00:00:00', '120.25.26'),
(4, 'md genty', '0125874265', 'genty@gmail.com', '*23AE809DDACAF96AF0FD78ED04B6A265E05AA257', '1995-02-02', 1, 'NA', 1, '', 'A', '0000-00-00 00:00:00', '120.25.26'),
(13, 'sagor', '01257951255', 'sagor@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-04-13', 1, 'kustia', 4, 'noimage.png', 'A', '2021-03-29 00:00:00', '120.25.26'),
(14, 'sultan', '016575655213', 'sultan@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-04-14', 1, 'kallanput', 2, NULL, 'u', '2021-04-17 22:41:56', '128.25.25'),
(15, 'parvej', '0168744662', 'parvej@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-04-08', 1, 'nakhalpara', 1, 'noimage.png', 'u', '2021-03-29 00:00:00', '120.25.26'),
(16, 'pias', '0159716851', 'pias@gmail.com', '*00A51F3F48415C7D4E8908980D443C29C69B60C9', '2021-04-21', 1, 'sp road', 4, 'abc.jpg', 'u', '2021-03-29 00:00:00', '120.25.26');

-- --------------------------------------------------------

--
-- Table structure for table `usersactive`
--

CREATE TABLE `usersactive` (
  `userid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `ip` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usersactive`
--

INSERT INTO `usersactive` (`userid`, `datetime`, `ip`) VALUES
(1, '2020-05-14 17:50:22', '10.10'),
(3, '2020-05-21 23:25:19', '20'),
(4, '2021-03-30 18:57:10', '20.02');

-- --------------------------------------------------------

--
-- Table structure for table `usersblock`
--

CREATE TABLE `usersblock` (
  `userid` int(11) NOT NULL,
  `datefrom` date DEFAULT NULL,
  `dateto` date DEFAULT NULL,
  `remarks` varchar(500) DEFAULT NULL,
  `adminuserid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usersblock`
--

INSERT INTO `usersblock` (`userid`, `datefrom`, `dateto`, `remarks`, `adminuserid`) VALUES
(4, '2020-04-27', '2020-05-20', '9', 1),
(4, '2020-04-27', '2020-05-20', '9', 1);

-- --------------------------------------------------------

--
-- Table structure for table `usersrating`
--

CREATE TABLE `usersrating` (
  `userid` int(11) NOT NULL,
  `ratebyuserid` int(11) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usersrating`
--

INSERT INTO `usersrating` (`userid`, `ratebyuserid`, `datetime`, `rating`) VALUES
(1, 1, '2021-03-31 01:05:18', 8),
(1, 3, '2021-03-31 01:09:18', 7),
(1, 4, '2021-03-31 01:05:51', 9),
(3, 1, '2021-04-14 16:47:07', 5),
(3, 4, '2021-04-14 16:46:47', 9),
(3, 13, '2021-04-14 16:48:01', 7),
(4, 13, '2021-04-14 16:46:47', 5),
(13, 1, '2021-04-14 16:48:01', 9);

-- --------------------------------------------------------

--
-- Table structure for table `usersverified`
--

CREATE TABLE `usersverified` (
  `userid` int(11) NOT NULL,
  `method` varchar(500) NOT NULL,
  `datetime` datetime DEFAULT current_timestamp(),
  `adminuserid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `usersverified`
--

INSERT INTO `usersverified` (`userid`, `method`, `datetime`, `adminuserid`) VALUES
(1, 'N/Aa', '2020-05-23 13:35:07', 4),
(1, 'N/Aa', '2020-05-23 22:14:44', 4),
(3, 'na', '2020-05-23 22:15:40', 4),
(1, 'N/Aa', '2021-03-31 01:28:34', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`id`),
  ADD KEY `countryid` (`countryid`);

--
-- Indexes for table `commodityarchive`
--
ALTER TABLE `commodityarchive`
  ADD PRIMARY KEY (`comodityid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `commoditydiscussion`
--
ALTER TABLE `commoditydiscussion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comodityid` (`comodityid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `commodityimage`
--
ALTER TABLE `commodityimage`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comodityid` (`comodityid`);

--
-- Indexes for table `commoditylinks`
--
ALTER TABLE `commoditylinks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comodityid` (`comodityid`);

--
-- Indexes for table `commodityvedio`
--
ALTER TABLE `commodityvedio`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comodityid` (`comodityid`);

--
-- Indexes for table `comodity`
--
ALTER TABLE `comodity`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conditionid` (`conditionid`),
  ADD KEY `locationid` (`locationid`),
  ADD KEY `priorityid` (`priorityid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `comodityapproved`
--
ALTER TABLE `comodityapproved`
  ADD PRIMARY KEY (`comodityid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `comoditycondition`
--
ALTER TABLE `comoditycondition`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `comodityprice`
--
ALTER TABLE `comodityprice`
  ADD KEY `comodityid` (`comodityid`);

--
-- Indexes for table `comoditypublish`
--
ALTER TABLE `comoditypublish`
  ADD PRIMARY KEY (`comodityid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `comodityreject`
--
ALTER TABLE `comodityreject`
  ADD PRIMARY KEY (`comodityid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `comoditysold`
--
ALTER TABLE `comoditysold`
  ADD PRIMARY KEY (`comodityid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cityid` (`cityid`);

--
-- Indexes for table `loginhistory`
--
ALTER TABLE `loginhistory`
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comodityid` (`comodityid`),
  ADD KEY `userid` (`userid`);

--
-- Indexes for table `priority`
--
ALTER TABLE `priority`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contact` (`contact`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `genderid` (`genderid`),
  ADD KEY `cityid` (`cityid`);

--
-- Indexes for table `usersactive`
--
ALTER TABLE `usersactive`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `usersblock`
--
ALTER TABLE `usersblock`
  ADD KEY `userid` (`userid`),
  ADD KEY `adminuserid` (`adminuserid`);

--
-- Indexes for table `usersrating`
--
ALTER TABLE `usersrating`
  ADD PRIMARY KEY (`userid`,`ratebyuserid`),
  ADD KEY `ratebyuserid` (`ratebyuserid`);

--
-- Indexes for table `usersverified`
--
ALTER TABLE `usersverified`
  ADD KEY `userid` (`userid`),
  ADD KEY `adminuserid` (`adminuserid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `commoditydiscussion`
--
ALTER TABLE `commoditydiscussion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `commodityimage`
--
ALTER TABLE `commodityimage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `commoditylinks`
--
ALTER TABLE `commoditylinks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `commodityvedio`
--
ALTER TABLE `commodityvedio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `comodity`
--
ALTER TABLE `comodity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `comoditycondition`
--
ALTER TABLE `comoditycondition`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `priority`
--
ALTER TABLE `priority`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `city`
--
ALTER TABLE `city`
  ADD CONSTRAINT `city_ibfk_1` FOREIGN KEY (`countryid`) REFERENCES `country` (`id`);

--
-- Constraints for table `commodityarchive`
--
ALTER TABLE `commodityarchive`
  ADD CONSTRAINT `commodityarchive_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`),
  ADD CONSTRAINT `commodityarchive_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `commoditydiscussion`
--
ALTER TABLE `commoditydiscussion`
  ADD CONSTRAINT `commoditydiscussion_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`),
  ADD CONSTRAINT `commoditydiscussion_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `commodityimage`
--
ALTER TABLE `commodityimage`
  ADD CONSTRAINT `commodityimage_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`);

--
-- Constraints for table `commoditylinks`
--
ALTER TABLE `commoditylinks`
  ADD CONSTRAINT `commoditylinks_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`);

--
-- Constraints for table `commodityvedio`
--
ALTER TABLE `commodityvedio`
  ADD CONSTRAINT `commodityvedio_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`);

--
-- Constraints for table `comodity`
--
ALTER TABLE `comodity`
  ADD CONSTRAINT `comodity_ibfk_1` FOREIGN KEY (`conditionid`) REFERENCES `comoditycondition` (`id`),
  ADD CONSTRAINT `comodity_ibfk_2` FOREIGN KEY (`locationid`) REFERENCES `location` (`id`),
  ADD CONSTRAINT `comodity_ibfk_3` FOREIGN KEY (`priorityid`) REFERENCES `priority` (`id`),
  ADD CONSTRAINT `comodity_ibfk_4` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `comodityapproved`
--
ALTER TABLE `comodityapproved`
  ADD CONSTRAINT `comodityapproved_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`),
  ADD CONSTRAINT `comodityapproved_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `comodityprice`
--
ALTER TABLE `comodityprice`
  ADD CONSTRAINT `comodityprice_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`);

--
-- Constraints for table `comoditypublish`
--
ALTER TABLE `comoditypublish`
  ADD CONSTRAINT `comoditypublish_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`),
  ADD CONSTRAINT `comoditypublish_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `comodityreject`
--
ALTER TABLE `comodityreject`
  ADD CONSTRAINT `comodityreject_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`),
  ADD CONSTRAINT `comodityreject_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `comoditysold`
--
ALTER TABLE `comoditysold`
  ADD CONSTRAINT `comoditysold_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`),
  ADD CONSTRAINT `comoditysold_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `location_ibfk_1` FOREIGN KEY (`cityid`) REFERENCES `city` (`id`);

--
-- Constraints for table `loginhistory`
--
ALTER TABLE `loginhistory`
  ADD CONSTRAINT `loginhistory_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`comodityid`) REFERENCES `comodity` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`genderid`) REFERENCES `gender` (`id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`cityid`) REFERENCES `city` (`id`);

--
-- Constraints for table `usersactive`
--
ALTER TABLE `usersactive`
  ADD CONSTRAINT `usersactive_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`);

--
-- Constraints for table `usersblock`
--
ALTER TABLE `usersblock`
  ADD CONSTRAINT `usersblock_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `usersblock_ibfk_2` FOREIGN KEY (`adminuserid`) REFERENCES `users` (`id`);

--
-- Constraints for table `usersrating`
--
ALTER TABLE `usersrating`
  ADD CONSTRAINT `usersrating_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `usersrating_ibfk_2` FOREIGN KEY (`ratebyuserid`) REFERENCES `users` (`id`);

--
-- Constraints for table `usersverified`
--
ALTER TABLE `usersverified`
  ADD CONSTRAINT `usersverified_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `usersverified_ibfk_2` FOREIGN KEY (`adminuserid`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
