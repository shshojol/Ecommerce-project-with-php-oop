<?php
SESSION_start();
$admin = array('users', 'comodity','myaccount', 'country', 'city', 'comodityapproved',
'comodityarchive', 'comoditycondition', 'comoditydiscussion', 'comodityimage', 'comoditylinks',
'comodityprice', 'comoditypublish', 'comodityreject', 'comoditysold',
'comodityvideo', 'gender', 'location', 'loginhistory', 'messages', 'priority',
'usersactive', 'usersblock', 'usersrating', 'usersverified');
$public = array('message', 'i_need_something');

$cn = mysqli_connect('localhost', 'root', '', 'bitm2');
include('include/htmlhelper.php');
include('include/dal/base.php');
include('include/dal/country.php');
include('include/dal/city.php');
include('include/dal/gender.php');
include('include/dal/users.php');
include('include/dal/uactive.php');
include('include/dal/loginhistory.php');
include('include/dal/usersblock.php');
include('include/dal/usersrating.php');
include('include/dal/usersverified.php');
include('include/dal/priority.php');
include('include/dal/comoditycondition.php');
include('include/dal/comodity.php');
include('include/dal/location.php');
include('include/dal/comodityapproved.php');
include('include/dal/image.php');
include('include/dal/link.php');
include('include/dal/comodityprice.php');
include('include/dal/comoditypublish.php');
include('include/dal/comodityreject.php');
include('include/dal/comoditysold.php');
include('include/dal/comodityvideo.php');
include('include/dal/comodityarchive.php');
include('include/dal/comoditydiscussion.php');
include('include/dal/messages.php');
$html = new htmlhelper();

$controller = "home";
$view = "index";
$layout  = "publiclayout";


if(isset($_GET['controller']))
{
    $controller = $_GET['controller'];
}

if(in_array($controller, $admin))
{
    $layout = "adminlayout";
}

if(isset($_GET['view']))
{
    $view = $_GET['view'];
}


//admin login 
if(isset($_POST['btnLogin']))
{
    $usr = new users();
    $usr->email = $_POST['email'];
    $usr->password = $_POST['password'];

    if($usr->login())
        { 
            if($usr->type == 'A')
            {
                $_SESSION['id'] = $usr->id;
                $_SESSION['name'] = $usr->name;
                $_SESSION['email'] = $usr->email;
                $_SESSION['type'] = $usr->type;
                if($view == 'login')
                    $view = "loginsuccess";
            }
            else{
                $_SESSION['message'] = "Not an admit account";
            }   
        }
        else{
            $_SESSION['message'] = "username password not matched";
        } 
}

//public login 
if(isset($_POST['btnLoginPublic']))
{
    $usr = new users();
    $usr->email = $_POST['email'];
    $usr->password = $_POST['password'];

    if($usr->login())
        { 
                $_SESSION['id'] = $usr->id;
                $_SESSION['name'] = $usr->name;
                $_SESSION['email'] = $usr->email;
                $_SESSION['type'] = $usr->type;
                if($view == 'login')
                    $view = "loginsuccess";
       
        }
        else{
            $_SESSION['message'] = "username password not matched";
        } 
}

//logout code
if($view == 'logout')
{
    unset($_SESSION['id']);
    unset($_SESSION['name']);
    unset($_SESSION['email']);
    unset($_SESSION['type']);
    $view = "logout";
}


include("views/layout/".$layout.".php");

function pagetitle()
{
    global $controller, $view;
    echo "<span class='title'><b>".ucwords($controller)."</b> | <i>".str_replace("_", " ", ucwords($view))."</i></span><br>";
}

function title()
{
    global $controller, $view;
    echo ucwords($controller)." | ".ucwords($view);
}

function renderbody()
{
    global $controller, $view, $layout, $html, $cn, $admin, $public;
    if(in_array($controller, $admin))
    {
        if(!isset($_SESSION['type']))
        {
            $_SESSION['message'] = "you have to login  to view this content";
            $controller = "myaccount";
            $view = "login";
        }
        elseif($_SESSION['type'] != "A")
        {
            $_SESSION['message'] = "you have to login with admin to view this content";
            $controller = "myaccount";
            $view = "login";
        }
    }
    elseif(in_array($view, $public))
    {
        if(!isset($_SESSION['type']))
        {
            $_SESSION['message'] = "you have to login  to view this content";
            $controller = "account";
            $view = "login";
        }
    }
    $fp = "views/".$controller."/".$view."";
    pagetitle();
    if(file_exists($fp.".php"))
    {      
        include ($fp.".php");  
    }
    elseif(file_exists($fp.".html"))
    {
        include ($fp.".html");
    }
    else{
        include ('views/warning.php');
    }

}

$_SESSION['message'] = "";

